export const apiPrefix = '/'
