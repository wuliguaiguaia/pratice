import React from 'react'
import styles from './index.scss'

const Footer = () => {
  const a = 1
  return (
    <div className={styles.footer}>
      footer
      {a}
    </div>
  )
}

export default Footer
