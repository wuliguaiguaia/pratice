/* editor */
export const UpdateDocData = Symbol('update doc data')
export const UpdateEditorState = Symbol('update editor state')
export const UpdateEditingStatus = Symbol('update editing status')
export const UpdateEditingHelperKeys = Symbol('update editing helper keys')


/* common */
export const UpdateCommonState = Symbol('update common state')
