import React from 'react'

const userList = () => {
  const a = 'userlist'
  return (
    <div>
      { a}
      fdsfsd
    </div>
  )
}

export default userList
