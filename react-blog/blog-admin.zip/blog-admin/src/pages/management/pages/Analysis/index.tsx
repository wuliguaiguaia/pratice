import React from 'react'
import styles from './index.scss'

const Analysis = () => {
  const s = ''
  return (
    <div className={styles.analysis}>
      {s}
      {' '}
      analysis
    </div>
  )
}
export default Analysis
