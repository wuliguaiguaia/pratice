import React from 'react'

const Register = () => {
  const a = 'register'
  return <div>{a}</div>
}

export default Register
