import React from 'react'

const PasswordReset = () => {
  const a = 'PasswordReset'
  return <div>{a}</div>
}

export default PasswordReset
