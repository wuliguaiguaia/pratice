import React from 'react'

const MyForm = () => {
  console.log(MyForm)
  return <div />
}

export default MyForm
