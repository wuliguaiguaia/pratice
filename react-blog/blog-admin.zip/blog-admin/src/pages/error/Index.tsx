import React from 'react'

const Error = () => {
  const a = 0
  return (
    <div>
      Error
      {' '}
      {a}
    </div>
  )
}

export default Error
