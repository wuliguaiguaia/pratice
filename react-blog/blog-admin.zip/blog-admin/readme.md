nrm use taobao
npm i
npm run start

npx browserslist：支持哪些浏览器
