const http = require('http');
const { spawn } = require('child_process'); // 子进程, 用来执行脚本
const { PORT, SECRET } = require('./src/config');
const { sign, resultString } = require('./src/utils'); // 工具文件

const server = http.createServer((req, res) => {
    // 打印进来的请求
    console.log(`--- ${req.method} --- ${req.url} ---`);
    // 设置header为json格式
    res.setHeader('Content-Type', 'application/json');

    if (req.method === 'POST' && req.url === '/webhook') {
        console.log('--- 命中webhook ---');
        // 获取body
        let buffers = [];
        req.on('data', buffer => {
            buffers.push(buffer);
        });
        req.on('end', () => {
            let body = Buffer.concat(buffers);
            // 获取header中event的字段, github 为push, gitee为 Push Hook
            let event = req.headers['x-github-event'] || req.headers['x-gitee-event'];
            console.log(`--- Event 名字: ${event}  ---`);
            console.log(req.headers['user-agent']);
            if (req.headers['user-agent'] === 'git-oschina-hook') {
                // gitee
                console.log('--- Gitee 平台 ---');
                // SECRET是在config.js中配置了
                if (req.headers['x-gitee-token'] === SECRET) {
                    if (event === 'Push Hook') {
                        console.log('--- push 任务命中 ---');
                        let payload = JSON.parse(body);
                        console.log(
                            `--- 任务名称: ${payload.repository.name}, 路径: ${payload.repository.path} ---`
                        );
                        // 开启子进程执行对应的脚本
                        // payload.repository.path 是gitee/github传来的repo的路径
                        // 通过path的值执行sh目录下对应的脚本
                        // 比如项目名字叫web_hook path的值就是web_hook
                        // 执行的脚本就是./sh/web_hook.sh
                        let child = spawn('sh', [`./sh/${payload.repository.path}.sh`]);
                        // 接收子进程传来的数据
                        let buffers = [];
                        child.stdout.on('data', buffer => {
                            console.log(`--- 接受data ${buffer.toString()} ---`);
                            buffers.push(buffer);
                        });
                        child.stdout.on('end', () => {
                            let log = Buffer.concat(buffers);
                            console.log(log.toString());
                            console.log('自动化拉取完毕');
                        });
                    }
                    // 返回的json, 配置在./src/resModel中
                    res.end(resultString('success', 0));
                } else {
                    // 其他的请求返回不允许
                    return res.end(resultString('Not Allowed', 1));
                }
            } else {
                // github
                // 基本和上面的gitee一样, 多一个校验身份的步骤
                console.log('--- Github 平台 ---');
                let signature = req.headers['x-hub-signature'];
                // sign 方法配置在utils.js中
                if (signature !== sign(body, SECRET)) {
                    return res.end(resultString('Not Allowed', 1));
                }
                if (event === 'push') {
                    console.log('--- push 任务命中 ---');
                    let payload = JSON.parse(body);
                    console.log(payload.repository.name);
                    let child = spawn('sh', [`./sh/${payload.repository.name}.sh`]);
                    let buffers = [];
                    child.stdout.on('data', buffer => {
                        buffers.push(buffer);
                    });
                    child.stdout.on('end', () => {
                        let log = Buffer.concat(buffers);
                        console.log(log.toString());
                        console.log('自动化拉取完毕');
                    });
                }
                res.end(resultString('success', 0));
            }
        });
    }
    res.end(resultString('Not Found', 1));
});

// 监听端口, PORT配置在config.js中
server.listen(PORT, () => {
    console.log(`web-hook listen on http://localhost:${PORT}`);
});
