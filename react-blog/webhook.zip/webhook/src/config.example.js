module.exports = {
    SECRET: '',
    PORT: '',
};