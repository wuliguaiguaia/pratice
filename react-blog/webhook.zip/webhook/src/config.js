module.exports = {
    SECRET: 'hdly0619',
    PORT: 9999,
};