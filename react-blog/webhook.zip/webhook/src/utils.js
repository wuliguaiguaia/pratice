const sign = () => { };
const resultString = () => {

};
module.exports = {
    sign,
    resultString,
};
